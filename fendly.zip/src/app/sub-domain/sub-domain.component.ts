import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-domain',
  templateUrl: './sub-domain.component.html',
  styleUrls: ['./sub-domain.component.css']
})
export class SubDomainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
