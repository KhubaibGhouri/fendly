import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirm-ip',
  templateUrl: './confirm-ip.component.html',
  styleUrls: ['./confirm-ip.component.css']
})
export class ConfirmIpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
