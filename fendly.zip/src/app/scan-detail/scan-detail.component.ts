import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scan-detail',
  templateUrl: './scan-detail.component.html',
  styleUrls: ['./scan-detail.component.css']
})
export class ScanDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
