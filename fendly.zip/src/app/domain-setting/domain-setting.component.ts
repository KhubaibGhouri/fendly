import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-domain-setting',
  templateUrl: './domain-setting.component.html',
  styleUrls: ['./domain-setting.component.css']
})
export class DomainSettingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
