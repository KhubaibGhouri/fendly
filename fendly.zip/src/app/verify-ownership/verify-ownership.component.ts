import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-ownership',
  templateUrl: './verify-ownership.component.html',
  styleUrls: ['./verify-ownership.component.css']
})
export class VerifyOwnershipComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
